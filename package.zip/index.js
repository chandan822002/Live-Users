const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const cors = require("cors");

const app = express();
app.use(bodyParser.json());
app.use(cors());

mongoose.connect("mongodb://127.0.0.1:27017/userdata")
    .then(() => console.log("MongoDB Connected"))
    .catch(err => console.log(err));


const userSchema = new mongoose.Schema({
    firstName: String,
    lastName: String,
    mobile: { type: String, match: /^[0-9]{10}$/ },
    email: { type: String, match: /\S+@\S+\.\S+/ },
    address: {
        street: String,
        city: String,
        state: String,
        country: String
    },
    loginId: { type: String, minlength: 5, maxlength: 12 },
    password: { type: String, minlength: 6 },
    creationTime: { type: Date, default: Date.now },
    lastUpdated: { type: Date, default: Date.now }
});

const User = mongoose.model("User", userSchema);

app.post("/api/users", async (req, res) => {
    console.log("Received request body:", req.body);
    try {
        const user = new User(req.body);
        await user.save();
        res.status(201).send(user);
    } catch (error) {
        console.log("Error saving user:", error);
        res.status(400).send(error);
    }
});

app.get("/api/users", async (req, res) => {
    const users = await User.find();
    res.send(users);
});

app.listen(3000, () => console.log("Server running on port 3000"));
